import bs4
import pandas as pd

with open('raw.html', 'r', encoding='utf-8') as fin:
    text = fin.read()
soup = bs4.BeautifulSoup(text, 'lxml')
tbody = soup.find_all('tbody')[0]
tr_list = tbody.find_all('tr')
result = [(1001 + i, int(tr.find_all('a')[1]['href'][32: -1])) for i, tr in enumerate(tr_list)]
df = pd.DataFrame(result)
df.to_csv('problem.csv', index=None)
